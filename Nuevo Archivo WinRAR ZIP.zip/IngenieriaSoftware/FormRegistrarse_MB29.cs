﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IngenieriaSoftware
{
    public partial class FormRegistrarse_MB29 : Form
    {
        public FormRegistrarse_MB29()
        {
            InitializeComponent();
        }
    }
}
