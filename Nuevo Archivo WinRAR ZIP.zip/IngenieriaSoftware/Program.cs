﻿using BLL_MB29;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using UI_MB29;

namespace IngenieriaSoftware
{
    internal static class Program
    {
        /// <summary>
        /// Punto de entrada principal para la aplicación.
        /// </summary>
        [STAThread]
        static void Main()
        {
            ServicioUsuarios_MB29.Inicializar_MB29();
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new FormLogin_MB29());

            FormLogin_MB29 loginForm = new FormLogin_MB29();

            while (true)
            {
                if (loginForm.ShowDialog() == DialogResult.OK && loginForm.UsuarioAutenticado != null)
                {
                    //Pasa UsuarioAutenticado y lista singleton
                    using (var principal = new FormPrincipal_MB29(loginForm.UsuarioAutenticado, ServicioUsuarios_MB29.Usuarios))
                    {
                        Application.Run(principal);
                    }

                    loginForm = new FormLogin_MB29(); // Nuevo login
                    continue;
                }
                else
                {
                    break; // Sale del programa
                }
            }
        }
    }
}
