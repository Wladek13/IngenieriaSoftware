﻿using BE_MB29;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IngenieriaSoftware
{
    public partial class FormPrincipal_MB29 : Form
    {
        private Persona_MB29 usuarioLogueado;
        private List<Persona_MB29> listausuarios;
        public FormPrincipal_MB29(Persona_MB29 usuario, List<Persona_MB29> usuarios)
        {
            InitializeComponent();
            usuarioLogueado = usuario;
            listausuarios = usuarios;
        }
    }
}
