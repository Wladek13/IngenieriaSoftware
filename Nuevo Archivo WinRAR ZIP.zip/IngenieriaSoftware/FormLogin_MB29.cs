﻿using BE_MB29;
using BLL_MB29;
using IngenieriaSoftware;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UI_MB29
{
     public partial class FormLogin_MB29 : Form
     {
        
        public FormLogin_MB29()
        {
            InitializeComponent();
        }

        public Persona_MB29 UsuarioAutenticado { get; private set; }

        private void BtnLogin_Click(object sender, EventArgs e)
        {
            UsuarioAutenticado = ServicioUsuarios_MB29.Login(UserTxt.Text.Trim(), ContraTxt.Text.Trim());

            if(UsuarioAutenticado != null)
            {
                MessageBox.Show($"Bienvenido de nuevo {UsuarioAutenticado.Usuario}!");
            }
            else
            {
                MessageBox.Show("Usuario o contraseña incorrectos");
                UserTxt.Clear();
                ContraTxt.Clear();
                UserTxt.Focus();
            }
        }

        private void RegistrarBtn_Click(object sender, EventArgs e)
        {
            FormRegistrarse_MB29 Freg = new FormRegistrarse_MB29();
            Freg.Show();
        }

        private void RecuperarBtn_Click(object sender, EventArgs e)
        {
            FormRecuperar_MB29 Frec = new FormRecuperar_MB29();
            Frec.Show();
        }
     }
}
