﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BE_MB29;
using DAL_MB29;

namespace BLL_MB29
{
    public static class ServicioUsuarios_MB29
    {
        private static List<Persona_MB29> _usuarios;
        public static List<Persona_MB29> Usuarios
        {
            get
            {
                if (_usuarios == null)
                    _usuarios = new List<Persona_MB29>();
                return _usuarios;
            }
        }

        public static Persona_MB29 Login(string usuario, string contra)
        {
            return Usuarios.FirstOrDefault(u => u.IniciarSesion_MB29(usuario, contra));
        }

        public static void Inicializar_MB29()
        {
            if (_usuarios != null) return;

            var gestor = new GestorUsuarios_MB29();
            _usuarios = gestor.CargarUsuarios_MB29();
        }

        public static void Guardar_MB29(Persona_MB29 usuario)
        {
            var gestor = new GestorUsuarios_MB29();
            gestor.GuardarUsuario_MB29(usuario);
            _usuarios.Add(usuario);
        }

        public static void Modificar_MB29(Persona_MB29 usuario)
        {
            var gestor = new GestorUsuarios_MB29();
            gestor.ModificarUsuario_MB29(usuario);
            var index = _usuarios.FindIndex(u => u.IdPersona == usuario.IdPersona);
            if (index >= 0) _usuarios[index] = usuario;
        }

        public static void Eliminar_MB29(int idPersona)
        {
            var usuario = _usuarios.FirstOrDefault(u => u.IdPersona == idPersona);
            if (usuario == null) return;

            var gestor = new GestorUsuarios_MB29();
            _usuarios.Remove(usuario);
        }

        public static void Recargar_MB29()
        {
            var gestor = new GestorUsuarios_MB29();
            _usuarios = gestor.CargarUsuarios_MB29();
        }
    }
}
